﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProiectA2
{
    public static class Inputs
    {
        #region comboboxes
        public static bool correctFR { get; set; } = true;
        public static bool correctIRmax { get; set; } = true;
        public static bool correctIBS { get; set; } = true;
        public static bool correctMissCache { get; set; } = true;
        public static bool correctRegSetNumber { get; set; } = true;
        public static bool correctBlockSizeInstr { get; set; } = true;
        public static bool correctSizeIC { get; set; } = true;
        public static bool correctBlockSizeData { get; set; } = true;
        public static bool correctSizeDC { get; set; } = true;

        #endregion


        #region additionalConditions

        //IBS >= FR + IR -- first condition
        //IBS >= FR -- second condition
        //IR <= FR -- third condition

        public static bool firstConditionFulfilled { get; set; } = true;
        public static bool secondConditionFulfilled { get; set; } = true;
        public static bool thirdConditionFulfilled { get; set; } = true;

        #endregion

        public static bool ValuesValid()
        {
            return correctFR && correctIRmax && correctIBS && correctMissCache && correctRegSetNumber && ((correctBlockSizeInstr
                && correctSizeIC) || (correctBlockSizeData && correctSizeDC)) && firstConditionFulfilled && secondConditionFulfilled && thirdConditionFulfilled;
        }
    }
}
