﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProiectA2
{
    public partial class FormMain : Form
    {
        bool correctInputs = true;
        bool uniport = false;
        bool fileChosen = false;

        string[] fetchRateVals = new string[] { "4", "8", "16" };
        string[] irMaxVals = new string[] { "2", "4", "8", "16" };
        string[] ibsVals = new string[] { "4", "8", "16", "32" };
        string[] nPenVals = new string[] { "10", "15", "20" };
        string[] registerVals = new string[] { "2", "4", "8", "16" };
        string[] blockSizeICVals = new string[] { "4" };
        string[] blockSizeDCVals = new string[] { "4", "8", "16" };
        string[] sizeICDCVals = new string[] { "64", "128", "256", "512", "1024", "2048", "4096", "8192" };

        List<Instruction> instructionsFromBenchmark = new List<Instruction>();
        Instruction[,] instructionsFromMemory;

        int loadInstructions = 0;
        int storeInstructions = 0;
        int branchInstructions = 0;
        int arithmeticInstructions = 0;
        int totalInstructions = 0;

        int availableAccessToMemoryPerCycle = 0;
        int numberOfMemoryAccesses = 0;
        int missCachePenalty = 0;
        double cacheMiss = 0.1;

        //int oneCycle = 0;
        int ticks = 0;
        double issueRate = 0;

        int IRmax;
        int rowsNumber = 0;
        int PCnormal;

        string filePath = string.Empty;
        List<string> fileContent;

        public FormMain()
        {
            InitializeComponent();
        }

        private void WriteLoadInstructions()
        {
            tbLoad.Text = Convert.ToString(loadInstructions);
        }
        private void WriteStoreInstructions()
        {
            tbStore.Text = Convert.ToString(storeInstructions);
        }
        private void WriteBranchInstructions()
        {
            tbBranch.Text = Convert.ToString(branchInstructions);
        }
        private void WriteTotalInstructions()
        {
            tbTotal.Text = Convert.ToString(totalInstructions);
        }

        //private void WriteOneCycle()
        //{
        //    tbOneCycle.Text = Convert.ToString(oneCycle);
        //}

        private void WriteArithmeticInstructions()
        {
            tbArithmetic.Text = Convert.ToString(arithmeticInstructions);
        }
        private void WriteIssueRate()
        {
            tbIssueRate.Text = Convert.ToString(issueRate);
        }
        private void WriteTicks()
        {
            tbTicks.Text = Convert.ToString(ticks);
        }

        private void btnChooseFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Title = "Select A File";
            openDialog.Filter = "Trace (*.trc)|*.trc" + "|" +
                                "All Files (*.*)|*.*";
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                tbPath.Text = openDialog.FileName;
                filePath = openDialog.FileName;
                fileChosen = true;
            }

            ParseFile();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (fileChosen)
            {
                ResetAll();

                correctInputs = (ckBiport.Checked || ckUniport.Checked) && Inputs.ValuesValid();

                if (correctInputs)
                {
                    uniport = ckUniport.Checked;

                    availableAccessToMemoryPerCycle = uniport ? 1 : 2;

                    PCnormal = 0;

                    instructionsFromMemory = new Instruction[100000000, IRmax];

                    ExecuteInstructions();
                    CalculateStatistics();

                    WriteLoadInstructions();
                    WriteStoreInstructions();
                    WriteBranchInstructions();
                    WriteArithmeticInstructions();

                    WriteIssueRate();
                    WriteTicks();

                    WriteTotalInstructions();

                    //DeactivateButtons();

                    instructionsFromMemory = null;
                }
                else
                {
                    MessageBox.Show("Asigurati-va ca inputurile sunt corecte.", "Inputuri incorecte", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Nu ati ales niciun fisier!", "Alegeti fisier", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
        }

        //private void DeactivateButtons()
        //{
        //    btnStart.Enabled = false;
        //}

        private void ResetAll()
        {
            loadInstructions = 0;
            storeInstructions = 0;
            branchInstructions = 0;
            arithmeticInstructions = 0;
            totalInstructions = 0;
        }

        private void CalculateStatistics()
        {
            var latency = Convert.ToInt32(numudLatency.Value);
            var penalties = Convert.ToInt32(cbMissCache.SelectedItem);

            ticks = latency * rowsNumber;

            missCachePenalty = Convert.ToInt32(loadInstructions * cacheMiss * missCachePenalty);
            ticks += missCachePenalty;

            foreach (Instruction instruction in instructionsFromMemory)
            {
                if (instruction != null)
                {
                    if (numberOfMemoryAccesses < availableAccessToMemoryPerCycle)
                    {
                        if (instruction.instructionType == InstructionType.Load || instruction.instructionType == InstructionType.Store)
                        {
                            numberOfMemoryAccesses++;
                        }
                    }
                    else
                    {
                        if (instruction.instructionType == InstructionType.Load || instruction.instructionType == InstructionType.Store)
                        {
                            numberOfMemoryAccesses = 0;
                            ticks += latency;
                        }
                    }
                }
            }

            totalInstructions = loadInstructions + storeInstructions + branchInstructions + arithmeticInstructions;
            issueRate = (Convert.ToDouble(totalInstructions) / Convert.ToDouble(ticks));
        }

        private void ExecuteInstructions()
        {
            int row = 0;
            int col = 0;
            try
            {
                foreach (Instruction instruction in instructionsFromBenchmark)
                {
                    while (instruction.currentPC != PCnormal)
                    {
                        if (col == IRmax)
                        {
                            row++;
                            col = 0;
                        }

                        //adauga o instructiune alu in matricea instructiuniAduseDinMemorie
                        instructionsFromMemory[row, col++] = new Instruction
                        {
                            instructionType = InstructionType.Arithmetic
                        };

                        PCnormal++;
                        arithmeticInstructions++;
                    }

                    if (instruction.instructionType == InstructionType.Branch)
                    {
                        if (col == IRmax)
                        {
                            row++;
                            col = 0;
                        }

                        //adauga o instructiune B in matricea instructiuniAduseDinMemorie
                        instructionsFromMemory[row, col++] = instruction;

                        PCnormal = instruction.targetAddress;
                        branchInstructions++;
                    }

                    if (instruction.instructionType == InstructionType.Store)
                    {
                        if (col == IRmax)
                        {
                            row++;
                            col = 0;
                        }

                        //adauga o instructiune S in matricea instructiuniAduseDinMemorie
                        instructionsFromMemory[row, col++] = instruction;

                        PCnormal++;
                        storeInstructions++;
                    }

                    if (instruction.instructionType == InstructionType.Load)
                    {
                        if (col == IRmax)
                        {
                            row++;
                            col = 0;
                        }

                        //adauga o instructiune L in matricea instructiuniAduseDinMemorie
                        instructionsFromMemory[row, col++] = instruction;

                        PCnormal++;
                        loadInstructions++;
                    }
                }

                rowsNumber = row;
            }
            catch (Exception ex)
            {

            }
        }

        private void ParseFile()
        {
            instructionsFromBenchmark.Clear();

            if (!String.IsNullOrEmpty(filePath))
            {
                fileContent = File.ReadAllText(filePath).Split(' ').Select(a => a.Trim()).ToList();
                fileContent = fileContent.Where(x => string.IsNullOrWhiteSpace(x) == false).ToList();
                for (int i = 0; i < fileContent.Count; i += 3)
                {
                    Instruction instruction = new Instruction
                    {
                        instructionType = GetInstructionType(fileContent[i]),
                        currentPC = Convert.ToInt32(fileContent[i + 1]),
                        targetAddress = Convert.ToInt32(fileContent[i + 2])
                    };
                    instructionsFromBenchmark.Add(instruction);
                }
            }
        }

        private InstructionType? GetInstructionType(string instructionShortcut)
        {
            switch (instructionShortcut)
            {
                case "B":
                    return InstructionType.Branch;
                case "L":
                    return InstructionType.Load;
                case "S":
                    return InstructionType.Store;
                default: break;
            }
            return null;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbFR.Items.AddRange(fetchRateVals);
            cbIRmax.Items.AddRange(irMaxVals);
            cbIBS.Items.AddRange(ibsVals);
            cbMissCache.Items.AddRange(nPenVals);
            cbRegSetNumber.Items.AddRange(registerVals);
            cbBlockSizeInstr.Items.AddRange(blockSizeICVals);
            cbBlockSizeData.Items.AddRange(blockSizeDCVals);
            cbSizeIC.Items.AddRange(sizeICDCVals);
            cbSizeDC.Items.AddRange(sizeICDCVals);

            cbBlockSizeInstr.SelectedIndex = 0;
            cbBlockSizeData.SelectedIndex = 0;
            cbSizeDC.SelectedIndex = 0;
            cbSizeIC.SelectedIndex = 0;
        }

        #region CheckParams
        private void cbFR_SelectionChangeCommitted(object sender, EventArgs e)
        {
            var valueFR = Convert.ToInt32(cbFR.SelectedItem);
            var valueIBS = Convert.ToInt32(cbIBS.SelectedItem);
            var valueIR = Convert.ToInt32(cbIRmax.SelectedItem);

            if (valueIBS != 0) //valoare default 0 daca nu e setat nimic
            {
                if (!(valueIBS >= valueFR)) //IBS >= FR
                {
                    MessageBox.Show("Alegeti alta valoare pentru FR; a se tine cont ca FR <= IBS.", "Fetch Rate incorect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Inputs.secondConditionFulfilled = false;
                }
                else
                {
                    Inputs.secondConditionFulfilled = true;
                }
            }


            if (valueIR != 0) //valoare default 0 daca nu e setat nimic
            {
                if (!(valueIR <= valueFR)) //IR <= FR
                {
                    MessageBox.Show("Alegeti alta valoare pentru FR; a se tine cont ca IR <= FR.", "Fetch Rate incorect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Inputs.thirdConditionFulfilled = false;
                }
                else
                {
                    Inputs.thirdConditionFulfilled = true;
                }
            }
        }

        private void cbIRmax_SelectionChangeCommitted(object sender, EventArgs e)
        {
            var valueFR = Convert.ToInt32(cbFR.SelectedItem);
            var valueIR = Convert.ToInt32(cbIRmax.SelectedItem);
            var valueIBS = Convert.ToInt32(cbIBS.SelectedItem);

            IRmax = valueIR;

            if (valueFR != 0) //valoare default 0 daca nu e setat nimic
            {
                if (!(valueIR <= valueFR)) //IR <= FR
                {
                    MessageBox.Show("Alegeti alta valoare pentru IR; a se tine cont ca IR <= FR.", "Issue Rate maxim incorect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Inputs.thirdConditionFulfilled = false;
                }
                else
                {
                    Inputs.thirdConditionFulfilled = true;
                }

                if (valueIBS != 0) //valoare default 0 daca nu e setat nimic
                {
                    if (!(valueIBS >= valueIR)) //IBS >= FR
                    {
                        MessageBox.Show("Alegeti alta valoare pentru IR; a se tine cont ca IBS >= FR.", "Issue Rate maxim incorect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Inputs.secondConditionFulfilled = false;
                    }
                    else
                    {
                        Inputs.secondConditionFulfilled = true;
                    }
                }
            }
        }
        private void cbIBS_SelectionChangeCommitted(object sender, EventArgs e)
        {
            var valueFR = Convert.ToInt32(cbFR.SelectedItem);
            var valueIR = Convert.ToInt32(cbIRmax.SelectedItem);
            var valueIBS = Convert.ToInt32(cbIBS.SelectedItem);

            if (valueFR != 0) //valoare default 0 daca nu e setat nimic
            {
                if (!(valueIBS >= valueFR)) //IBS >= FR
                {
                    MessageBox.Show("Alegeti alta valoare pentru IR; a se tine cont ca IBS >= FR.", "Issue Rate maxim incorect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Inputs.secondConditionFulfilled = false;
                }
                else
                {
                    Inputs.secondConditionFulfilled = true;
                }

                if (valueIR != 0) //valoare default 0 daca nu e setat nimic
                {
                    if (!(valueIBS >= valueFR + valueIR)) //IBS >= FR + IR
                    {
                        MessageBox.Show("Alegeti alta valoare pentru IR; a se tine cont ca IBS >= FR + IR.", "Issue Rate maxim incorect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Inputs.firstConditionFulfilled = false;
                    }
                    else
                    {
                        Inputs.firstConditionFulfilled = true;
                    }
                }
            }
        }

        private void ckUniport_CheckedChanged(object sender, EventArgs e)
        {
            if (ckBiport.Checked && ckUniport.Checked)
            {
                MessageBox.Show("Bifati Uniport sau Biport.", "Conflict", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ckUniport.Checked = false;
            }
        }

        private void ckBiport_CheckedChanged(object sender, EventArgs e)
        {
            if (ckBiport.Checked && ckUniport.Checked)
            {
                MessageBox.Show("Bifati Uniport sau Biport.", "Conflict", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ckBiport.Checked = false;
            }
        }

        private void cbRegSetNumber_TextChanged(object sender, EventArgs e)
        {
            if (!cbRegSetNumber.Items.Contains(cbRegSetNumber.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctRegSetNumber = false;
            }
            else
            {
                Inputs.correctRegSetNumber = true;
            }
        }

        private void cbMissCache_TextChanged(object sender, EventArgs e)
        {
            if (!cbMissCache.Items.Contains(cbMissCache.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctMissCache = false;
            }
            else
            {
                Inputs.correctMissCache = true;
            }
        }
        private void cbIBS_TextChanged(object sender, EventArgs e)
        {
            if (!cbIBS.Items.Contains(cbIBS.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctIBS = false;
            }
            else
            {
                Inputs.correctIBS = true;
            }
        }
        private void cbIRmax_TextChanged(object sender, EventArgs e)
        {
            if (!cbIRmax.Items.Contains(cbIRmax.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctIRmax = false;
            }
            else
            {
                Inputs.correctIRmax = true;
            }
        }
        private void cbFR_TextChanged(object sender, EventArgs e)
        {
            if (!cbFR.Items.Contains(cbFR.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctFR = false;
            }
            else
            {
                Inputs.correctFR = true;
            }
        }


        private void cbBlockSizeInstr_TextChanged(object sender, EventArgs e)
        {
            if (!cbBlockSizeInstr.Items.Contains(cbBlockSizeInstr.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctBlockSizeInstr = false;
            }
            else
            {
                Inputs.correctBlockSizeInstr = true;
            }
        }

        private void cbSizeIC_TextChanged(object sender, EventArgs e)
        {
            if (!cbSizeIC.Items.Contains(cbSizeIC.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctSizeIC = false;
            }
            else
            {
                Inputs.correctSizeIC = true;
            }
        }

        private void cbBlockSizeData_TextChanged(object sender, EventArgs e)
        {
            if (!cbBlockSizeData.Items.Contains(cbBlockSizeData.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctBlockSizeData = false;
            }
            else
            {
                Inputs.correctBlockSizeData = true;
            }
        }

        private void cbSizeDC_TextChanged(object sender, EventArgs e)
        {
            if (!cbSizeDC.Items.Contains(cbSizeDC.Text))
            {
                MessageBox.Show("Alegeti o valoare din dropdown!", "Valoare invalida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Inputs.correctSizeDC = false;
            }
            else
            {
                Inputs.correctSizeDC = true;
            }
        }

        #endregion
    }
}
