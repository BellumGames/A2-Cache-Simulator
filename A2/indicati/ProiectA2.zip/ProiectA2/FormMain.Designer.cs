﻿
namespace ProiectA2
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelParamSim = new System.Windows.Forms.Panel();
            this.numudLatency = new System.Windows.Forms.NumericUpDown();
            this.cbRegSetNumber = new System.Windows.Forms.ComboBox();
            this.lblRegSetNo = new System.Windows.Forms.Label();
            this.cbMissCache = new System.Windows.Forms.ComboBox();
            this.lblMissCache = new System.Windows.Forms.Label();
            this.lblLatency = new System.Windows.Forms.Label();
            this.lblIBS = new System.Windows.Forms.Label();
            this.cbIBS = new System.Windows.Forms.ComboBox();
            this.lblIRmax = new System.Windows.Forms.Label();
            this.cbIRmax = new System.Windows.Forms.ComboBox();
            this.lblFR = new System.Windows.Forms.Label();
            this.cbFR = new System.Windows.Forms.ComboBox();
            this.lblSimulatorParam = new System.Windows.Forms.Label();
            this.panelParamCache = new System.Windows.Forms.Panel();
            this.cbBlockSizeData = new System.Windows.Forms.ComboBox();
            this.cbSizeDC = new System.Windows.Forms.ComboBox();
            this.cbSizeIC = new System.Windows.Forms.ComboBox();
            this.cbBlockSizeInstr = new System.Windows.Forms.ComboBox();
            this.lblEqFR = new System.Windows.Forms.Label();
            this.lblSizeDC = new System.Windows.Forms.Label();
            this.lblBlockSizeData = new System.Windows.Forms.Label();
            this.lblSizeIC = new System.Windows.Forms.Label();
            this.lblBlockSizeInstr = new System.Windows.Forms.Label();
            this.lblDataCache = new System.Windows.Forms.Label();
            this.lblInstrCache = new System.Windows.Forms.Label();
            this.lblCacheParam = new System.Windows.Forms.Label();
            this.panelUniOrBiPort = new System.Windows.Forms.Panel();
            this.ckBiport = new System.Windows.Forms.CheckBox();
            this.ckUniport = new System.Windows.Forms.CheckBox();
            this.panelOptions = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnChooseFile = new System.Windows.Forms.Button();
            this.panelResults = new System.Windows.Forms.Panel();
            this.lblTicks = new System.Windows.Forms.Label();
            this.lblIR = new System.Windows.Forms.Label();
            this.lblArithmetic = new System.Windows.Forms.Label();
            this.tbTicks = new System.Windows.Forms.TextBox();
            this.tbIssueRate = new System.Windows.Forms.TextBox();
            this.tbArithmetic = new System.Windows.Forms.TextBox();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.tbBranch = new System.Windows.Forms.TextBox();
            this.tbStore = new System.Windows.Forms.TextBox();
            this.tbLoad = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblBranch = new System.Windows.Forms.Label();
            this.lblStore = new System.Windows.Forms.Label();
            this.lblLoad = new System.Windows.Forms.Label();
            this.lblResults = new System.Windows.Forms.Label();
            this.lblInstr = new System.Windows.Forms.Label();
            this.tbPath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelPath = new System.Windows.Forms.Panel();
            this.lblPath = new System.Windows.Forms.Label();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.panelParamSim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numudLatency)).BeginInit();
            this.panelParamCache.SuspendLayout();
            this.panelUniOrBiPort.SuspendLayout();
            this.panelOptions.SuspendLayout();
            this.panelResults.SuspendLayout();
            this.panelPath.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelParamSim
            // 
            this.panelParamSim.Controls.Add(this.numudLatency);
            this.panelParamSim.Controls.Add(this.cbRegSetNumber);
            this.panelParamSim.Controls.Add(this.lblRegSetNo);
            this.panelParamSim.Controls.Add(this.cbMissCache);
            this.panelParamSim.Controls.Add(this.lblMissCache);
            this.panelParamSim.Controls.Add(this.lblLatency);
            this.panelParamSim.Controls.Add(this.lblIBS);
            this.panelParamSim.Controls.Add(this.cbIBS);
            this.panelParamSim.Controls.Add(this.lblIRmax);
            this.panelParamSim.Controls.Add(this.cbIRmax);
            this.panelParamSim.Controls.Add(this.lblFR);
            this.panelParamSim.Controls.Add(this.cbFR);
            this.panelParamSim.Controls.Add(this.lblSimulatorParam);
            this.panelParamSim.Location = new System.Drawing.Point(23, 22);
            this.panelParamSim.Name = "panelParamSim";
            this.panelParamSim.Size = new System.Drawing.Size(230, 250);
            this.panelParamSim.TabIndex = 0;
            // 
            // numudLatency
            // 
            this.numudLatency.Location = new System.Drawing.Point(160, 138);
            this.numudLatency.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numudLatency.Name = "numudLatency";
            this.numudLatency.Size = new System.Drawing.Size(51, 20);
            this.numudLatency.TabIndex = 13;
            this.numudLatency.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cbRegSetNumber
            // 
            this.cbRegSetNumber.FormattingEnabled = true;
            this.cbRegSetNumber.Location = new System.Drawing.Point(160, 191);
            this.cbRegSetNumber.Name = "cbRegSetNumber";
            this.cbRegSetNumber.Size = new System.Drawing.Size(51, 21);
            this.cbRegSetNumber.TabIndex = 12;
            this.cbRegSetNumber.TextChanged += new System.EventHandler(this.cbRegSetNumber_TextChanged);
            // 
            // lblRegSetNo
            // 
            this.lblRegSetNo.AutoSize = true;
            this.lblRegSetNo.Location = new System.Drawing.Point(9, 199);
            this.lblRegSetNo.Name = "lblRegSetNo";
            this.lblRegSetNo.Size = new System.Drawing.Size(71, 13);
            this.lblRegSetNo.TabIndex = 11;
            this.lblRegSetNo.Text = "Nr. set registri";
            // 
            // cbMissCache
            // 
            this.cbMissCache.FormattingEnabled = true;
            this.cbMissCache.Location = new System.Drawing.Point(160, 161);
            this.cbMissCache.Name = "cbMissCache";
            this.cbMissCache.Size = new System.Drawing.Size(51, 21);
            this.cbMissCache.TabIndex = 10;
            this.cbMissCache.TextChanged += new System.EventHandler(this.cbMissCache_TextChanged);
            // 
            // lblMissCache
            // 
            this.lblMissCache.AutoSize = true;
            this.lblMissCache.Location = new System.Drawing.Point(9, 169);
            this.lblMissCache.Name = "lblMissCache";
            this.lblMissCache.Size = new System.Drawing.Size(116, 13);
            this.lblMissCache.TabIndex = 9;
            this.lblMissCache.Text = "N_PEN (miss in cache)";
            // 
            // lblLatency
            // 
            this.lblLatency.AutoSize = true;
            this.lblLatency.Location = new System.Drawing.Point(9, 138);
            this.lblLatency.Name = "lblLatency";
            this.lblLatency.Size = new System.Drawing.Size(107, 13);
            this.lblLatency.TabIndex = 8;
            this.lblLatency.Text = "Latenta (hit in cache)";
            // 
            // lblIBS
            // 
            this.lblIBS.AutoSize = true;
            this.lblIBS.Location = new System.Drawing.Point(9, 110);
            this.lblIBS.Name = "lblIBS";
            this.lblIBS.Size = new System.Drawing.Size(136, 13);
            this.lblIBS.TabIndex = 7;
            this.lblIBS.Text = "Instruction Buffer Size (IBS)";
            // 
            // cbIBS
            // 
            this.cbIBS.FormattingEnabled = true;
            this.cbIBS.Location = new System.Drawing.Point(160, 106);
            this.cbIBS.Name = "cbIBS";
            this.cbIBS.Size = new System.Drawing.Size(51, 21);
            this.cbIBS.TabIndex = 6;
            this.cbIBS.SelectionChangeCommitted += new System.EventHandler(this.cbIBS_SelectionChangeCommitted);
            this.cbIBS.TextChanged += new System.EventHandler(this.cbIBS_TextChanged);
            // 
            // lblIRmax
            // 
            this.lblIRmax.AutoSize = true;
            this.lblIRmax.Location = new System.Drawing.Point(9, 78);
            this.lblIRmax.Name = "lblIRmax";
            this.lblIRmax.Size = new System.Drawing.Size(130, 13);
            this.lblIRmax.TabIndex = 5;
            this.lblIRmax.Text = "Issue Rate Maxim (IRmax)";
            // 
            // cbIRmax
            // 
            this.cbIRmax.FormattingEnabled = true;
            this.cbIRmax.Location = new System.Drawing.Point(160, 75);
            this.cbIRmax.Name = "cbIRmax";
            this.cbIRmax.Size = new System.Drawing.Size(51, 21);
            this.cbIRmax.TabIndex = 4;
            this.cbIRmax.SelectionChangeCommitted += new System.EventHandler(this.cbIRmax_SelectionChangeCommitted);
            this.cbIRmax.TextChanged += new System.EventHandler(this.cbIRmax_TextChanged);
            // 
            // lblFR
            // 
            this.lblFR.AutoSize = true;
            this.lblFR.Location = new System.Drawing.Point(9, 49);
            this.lblFR.Name = "lblFR";
            this.lblFR.Size = new System.Drawing.Size(83, 13);
            this.lblFR.TabIndex = 3;
            this.lblFR.Text = "Fetch Rate (FR)";
            // 
            // cbFR
            // 
            this.cbFR.FormattingEnabled = true;
            this.cbFR.Location = new System.Drawing.Point(160, 41);
            this.cbFR.Name = "cbFR";
            this.cbFR.Size = new System.Drawing.Size(51, 21);
            this.cbFR.TabIndex = 2;
            this.cbFR.SelectionChangeCommitted += new System.EventHandler(this.cbFR_SelectionChangeCommitted);
            this.cbFR.TextChanged += new System.EventHandler(this.cbFR_TextChanged);
            // 
            // lblSimulatorParam
            // 
            this.lblSimulatorParam.AutoSize = true;
            this.lblSimulatorParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSimulatorParam.Location = new System.Drawing.Point(40, 0);
            this.lblSimulatorParam.Name = "lblSimulatorParam";
            this.lblSimulatorParam.Size = new System.Drawing.Size(149, 17);
            this.lblSimulatorParam.TabIndex = 1;
            this.lblSimulatorParam.Text = "Parametri simulator";
            // 
            // panelParamCache
            // 
            this.panelParamCache.Controls.Add(this.cbBlockSizeData);
            this.panelParamCache.Controls.Add(this.cbSizeDC);
            this.panelParamCache.Controls.Add(this.cbSizeIC);
            this.panelParamCache.Controls.Add(this.cbBlockSizeInstr);
            this.panelParamCache.Controls.Add(this.lblEqFR);
            this.panelParamCache.Controls.Add(this.lblSizeDC);
            this.panelParamCache.Controls.Add(this.lblBlockSizeData);
            this.panelParamCache.Controls.Add(this.lblSizeIC);
            this.panelParamCache.Controls.Add(this.lblBlockSizeInstr);
            this.panelParamCache.Controls.Add(this.lblDataCache);
            this.panelParamCache.Controls.Add(this.lblInstrCache);
            this.panelParamCache.Controls.Add(this.lblCacheParam);
            this.panelParamCache.Location = new System.Drawing.Point(268, 22);
            this.panelParamCache.Name = "panelParamCache";
            this.panelParamCache.Size = new System.Drawing.Size(306, 96);
            this.panelParamCache.TabIndex = 1;
            // 
            // cbBlockSizeData
            // 
            this.cbBlockSizeData.FormattingEnabled = true;
            this.cbBlockSizeData.Location = new System.Drawing.Point(255, 46);
            this.cbBlockSizeData.Name = "cbBlockSizeData";
            this.cbBlockSizeData.Size = new System.Drawing.Size(51, 21);
            this.cbBlockSizeData.TabIndex = 16;
            this.cbBlockSizeData.TextChanged += new System.EventHandler(this.cbBlockSizeData_TextChanged);
            // 
            // cbSizeDC
            // 
            this.cbSizeDC.FormattingEnabled = true;
            this.cbSizeDC.Location = new System.Drawing.Point(252, 72);
            this.cbSizeDC.Name = "cbSizeDC";
            this.cbSizeDC.Size = new System.Drawing.Size(51, 21);
            this.cbSizeDC.TabIndex = 15;
            this.cbSizeDC.TextChanged += new System.EventHandler(this.cbSizeDC_TextChanged);
            // 
            // cbSizeIC
            // 
            this.cbSizeIC.FormattingEnabled = true;
            this.cbSizeIC.Location = new System.Drawing.Point(85, 72);
            this.cbSizeIC.Name = "cbSizeIC";
            this.cbSizeIC.Size = new System.Drawing.Size(51, 21);
            this.cbSizeIC.TabIndex = 14;
            this.cbSizeIC.TextChanged += new System.EventHandler(this.cbSizeIC_TextChanged);
            // 
            // cbBlockSizeInstr
            // 
            this.cbBlockSizeInstr.FormattingEnabled = true;
            this.cbBlockSizeInstr.Location = new System.Drawing.Point(85, 46);
            this.cbBlockSizeInstr.Name = "cbBlockSizeInstr";
            this.cbBlockSizeInstr.Size = new System.Drawing.Size(51, 21);
            this.cbBlockSizeInstr.TabIndex = 13;
            this.cbBlockSizeInstr.TextChanged += new System.EventHandler(this.cbBlockSizeInstr_TextChanged);
            // 
            // lblEqFR
            // 
            this.lblEqFR.AutoSize = true;
            this.lblEqFR.Location = new System.Drawing.Point(142, 49);
            this.lblEqFR.Name = "lblEqFR";
            this.lblEqFR.Size = new System.Drawing.Size(27, 13);
            this.lblEqFR.TabIndex = 7;
            this.lblEqFR.Text = "=FR";
            // 
            // lblSizeDC
            // 
            this.lblSizeDC.AutoSize = true;
            this.lblSizeDC.Location = new System.Drawing.Point(189, 75);
            this.lblSizeDC.Name = "lblSizeDC";
            this.lblSizeDC.Size = new System.Drawing.Size(48, 13);
            this.lblSizeDC.TabIndex = 6;
            this.lblSizeDC.Text = "Size_DC";
            // 
            // lblBlockSizeData
            // 
            this.lblBlockSizeData.AutoSize = true;
            this.lblBlockSizeData.Location = new System.Drawing.Point(194, 49);
            this.lblBlockSizeData.Name = "lblBlockSizeData";
            this.lblBlockSizeData.Size = new System.Drawing.Size(55, 13);
            this.lblBlockSizeData.TabIndex = 5;
            this.lblBlockSizeData.Text = "Block size";
            // 
            // lblSizeIC
            // 
            this.lblSizeIC.AutoSize = true;
            this.lblSizeIC.Location = new System.Drawing.Point(24, 75);
            this.lblSizeIC.Name = "lblSizeIC";
            this.lblSizeIC.Size = new System.Drawing.Size(43, 13);
            this.lblSizeIC.TabIndex = 4;
            this.lblSizeIC.Text = "Size_IC";
            // 
            // lblBlockSizeInstr
            // 
            this.lblBlockSizeInstr.AutoSize = true;
            this.lblBlockSizeInstr.Location = new System.Drawing.Point(24, 49);
            this.lblBlockSizeInstr.Name = "lblBlockSizeInstr";
            this.lblBlockSizeInstr.Size = new System.Drawing.Size(55, 13);
            this.lblBlockSizeInstr.TabIndex = 3;
            this.lblBlockSizeInstr.Text = "Block size";
            // 
            // lblDataCache
            // 
            this.lblDataCache.AutoSize = true;
            this.lblDataCache.Location = new System.Drawing.Point(189, 17);
            this.lblDataCache.Name = "lblDataCache";
            this.lblDataCache.Size = new System.Drawing.Size(63, 13);
            this.lblDataCache.TabIndex = 2;
            this.lblDataCache.Text = "Data cache";
            // 
            // lblInstrCache
            // 
            this.lblInstrCache.AutoSize = true;
            this.lblInstrCache.Location = new System.Drawing.Point(24, 17);
            this.lblInstrCache.Name = "lblInstrCache";
            this.lblInstrCache.Size = new System.Drawing.Size(89, 13);
            this.lblInstrCache.TabIndex = 1;
            this.lblInstrCache.Text = "Instruction cache";
            // 
            // lblCacheParam
            // 
            this.lblCacheParam.AutoSize = true;
            this.lblCacheParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCacheParam.Location = new System.Drawing.Point(24, 0);
            this.lblCacheParam.Name = "lblCacheParam";
            this.lblCacheParam.Size = new System.Drawing.Size(252, 17);
            this.lblCacheParam.TabIndex = 0;
            this.lblCacheParam.Text = "Parametri cache (mapare directa)";
            // 
            // panelUniOrBiPort
            // 
            this.panelUniOrBiPort.Controls.Add(this.ckBiport);
            this.panelUniOrBiPort.Controls.Add(this.ckUniport);
            this.panelUniOrBiPort.Location = new System.Drawing.Point(268, 124);
            this.panelUniOrBiPort.Name = "panelUniOrBiPort";
            this.panelUniOrBiPort.Size = new System.Drawing.Size(306, 30);
            this.panelUniOrBiPort.TabIndex = 2;
            // 
            // ckBiport
            // 
            this.ckBiport.AutoSize = true;
            this.ckBiport.Location = new System.Drawing.Point(167, 8);
            this.ckBiport.Name = "ckBiport";
            this.ckBiport.Size = new System.Drawing.Size(53, 17);
            this.ckBiport.TabIndex = 3;
            this.ckBiport.Text = "Biport";
            this.ckBiport.UseVisualStyleBackColor = true;
            this.ckBiport.CheckedChanged += new System.EventHandler(this.ckBiport_CheckedChanged);
            // 
            // ckUniport
            // 
            this.ckUniport.AutoSize = true;
            this.ckUniport.Location = new System.Drawing.Point(27, 8);
            this.ckUniport.Name = "ckUniport";
            this.ckUniport.Size = new System.Drawing.Size(60, 17);
            this.ckUniport.TabIndex = 2;
            this.ckUniport.Text = "Uniport";
            this.ckUniport.UseVisualStyleBackColor = true;
            this.ckUniport.CheckedChanged += new System.EventHandler(this.ckUniport_CheckedChanged);
            // 
            // panelOptions
            // 
            this.panelOptions.Controls.Add(this.btnExit);
            this.panelOptions.Controls.Add(this.btnStart);
            this.panelOptions.Controls.Add(this.btnChooseFile);
            this.panelOptions.Location = new System.Drawing.Point(268, 160);
            this.panelOptions.Name = "panelOptions";
            this.panelOptions.Size = new System.Drawing.Size(306, 46);
            this.panelOptions.TabIndex = 3;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(230, 13);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(64, 23);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(113, 13);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(96, 23);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start simulare";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnChooseFile
            // 
            this.btnChooseFile.Location = new System.Drawing.Point(12, 13);
            this.btnChooseFile.Name = "btnChooseFile";
            this.btnChooseFile.Size = new System.Drawing.Size(75, 23);
            this.btnChooseFile.TabIndex = 1;
            this.btnChooseFile.Text = "Alege fisier";
            this.btnChooseFile.UseVisualStyleBackColor = true;
            this.btnChooseFile.Click += new System.EventHandler(this.btnChooseFile_Click);
            // 
            // panelResults
            // 
            this.panelResults.Controls.Add(this.lblTicks);
            this.panelResults.Controls.Add(this.lblIR);
            this.panelResults.Controls.Add(this.lblArithmetic);
            this.panelResults.Controls.Add(this.tbTicks);
            this.panelResults.Controls.Add(this.tbIssueRate);
            this.panelResults.Controls.Add(this.tbArithmetic);
            this.panelResults.Controls.Add(this.tbTotal);
            this.panelResults.Controls.Add(this.tbBranch);
            this.panelResults.Controls.Add(this.tbStore);
            this.panelResults.Controls.Add(this.tbLoad);
            this.panelResults.Controls.Add(this.lblTotal);
            this.panelResults.Controls.Add(this.lblBranch);
            this.panelResults.Controls.Add(this.lblStore);
            this.panelResults.Controls.Add(this.lblLoad);
            this.panelResults.Controls.Add(this.lblResults);
            this.panelResults.Controls.Add(this.lblInstr);
            this.panelResults.Location = new System.Drawing.Point(23, 288);
            this.panelResults.Name = "panelResults";
            this.panelResults.Size = new System.Drawing.Size(551, 179);
            this.panelResults.TabIndex = 4;
            // 
            // lblTicks
            // 
            this.lblTicks.AutoSize = true;
            this.lblTicks.Location = new System.Drawing.Point(348, 118);
            this.lblTicks.Name = "lblTicks";
            this.lblTicks.Size = new System.Drawing.Size(33, 13);
            this.lblTicks.TabIndex = 17;
            this.lblTicks.Text = "Ticks";
            // 
            // lblIR
            // 
            this.lblIR.AutoSize = true;
            this.lblIR.Location = new System.Drawing.Point(326, 67);
            this.lblIR.Name = "lblIR";
            this.lblIR.Size = new System.Drawing.Size(58, 13);
            this.lblIR.TabIndex = 16;
            this.lblIR.Text = "Issue Rate";
            // 
            // lblArithmetic
            // 
            this.lblArithmetic.AutoSize = true;
            this.lblArithmetic.Location = new System.Drawing.Point(26, 117);
            this.lblArithmetic.Name = "lblArithmetic";
            this.lblArithmetic.Size = new System.Drawing.Size(53, 13);
            this.lblArithmetic.TabIndex = 15;
            this.lblArithmetic.Text = "Arithmetic";
            // 
            // tbTicks
            // 
            this.tbTicks.Location = new System.Drawing.Point(394, 115);
            this.tbTicks.Name = "tbTicks";
            this.tbTicks.ReadOnly = true;
            this.tbTicks.Size = new System.Drawing.Size(100, 20);
            this.tbTicks.TabIndex = 14;
            // 
            // tbIssueRate
            // 
            this.tbIssueRate.Location = new System.Drawing.Point(394, 64);
            this.tbIssueRate.Name = "tbIssueRate";
            this.tbIssueRate.ReadOnly = true;
            this.tbIssueRate.Size = new System.Drawing.Size(100, 20);
            this.tbIssueRate.TabIndex = 13;
            // 
            // tbArithmetic
            // 
            this.tbArithmetic.Location = new System.Drawing.Point(100, 114);
            this.tbArithmetic.Name = "tbArithmetic";
            this.tbArithmetic.ReadOnly = true;
            this.tbArithmetic.Size = new System.Drawing.Size(74, 20);
            this.tbArithmetic.TabIndex = 12;
            // 
            // tbTotal
            // 
            this.tbTotal.Location = new System.Drawing.Point(100, 144);
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.ReadOnly = true;
            this.tbTotal.Size = new System.Drawing.Size(74, 20);
            this.tbTotal.TabIndex = 11;
            // 
            // tbBranch
            // 
            this.tbBranch.Location = new System.Drawing.Point(100, 85);
            this.tbBranch.Name = "tbBranch";
            this.tbBranch.ReadOnly = true;
            this.tbBranch.Size = new System.Drawing.Size(74, 20);
            this.tbBranch.TabIndex = 10;
            // 
            // tbStore
            // 
            this.tbStore.Location = new System.Drawing.Point(100, 52);
            this.tbStore.Name = "tbStore";
            this.tbStore.ReadOnly = true;
            this.tbStore.Size = new System.Drawing.Size(74, 20);
            this.tbStore.TabIndex = 9;
            // 
            // tbLoad
            // 
            this.tbLoad.Location = new System.Drawing.Point(100, 26);
            this.tbLoad.Name = "tbLoad";
            this.tbLoad.ReadOnly = true;
            this.tbLoad.Size = new System.Drawing.Size(74, 20);
            this.tbLoad.TabIndex = 8;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(50, 147);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(31, 13);
            this.lblTotal.TabIndex = 7;
            this.lblTotal.Text = "Total";
            // 
            // lblBranch
            // 
            this.lblBranch.AutoSize = true;
            this.lblBranch.Location = new System.Drawing.Point(41, 88);
            this.lblBranch.Name = "lblBranch";
            this.lblBranch.Size = new System.Drawing.Size(41, 13);
            this.lblBranch.TabIndex = 6;
            this.lblBranch.Text = "Branch";
            // 
            // lblStore
            // 
            this.lblStore.AutoSize = true;
            this.lblStore.Location = new System.Drawing.Point(50, 55);
            this.lblStore.Name = "lblStore";
            this.lblStore.Size = new System.Drawing.Size(32, 13);
            this.lblStore.TabIndex = 5;
            this.lblStore.Text = "Store";
            // 
            // lblLoad
            // 
            this.lblLoad.AutoSize = true;
            this.lblLoad.Location = new System.Drawing.Point(49, 29);
            this.lblLoad.Name = "lblLoad";
            this.lblLoad.Size = new System.Drawing.Size(31, 13);
            this.lblLoad.TabIndex = 4;
            this.lblLoad.Text = "Load";
            // 
            // lblResults
            // 
            this.lblResults.AutoSize = true;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(377, 0);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(77, 17);
            this.lblResults.TabIndex = 3;
            this.lblResults.Text = "Rezultate";
            // 
            // lblInstr
            // 
            this.lblInstr.AutoSize = true;
            this.lblInstr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstr.Location = new System.Drawing.Point(65, 0);
            this.lblInstr.Name = "lblInstr";
            this.lblInstr.Size = new System.Drawing.Size(88, 17);
            this.lblInstr.TabIndex = 2;
            this.lblInstr.Text = "Instructiuni";
            // 
            // tbPath
            // 
            this.tbPath.Location = new System.Drawing.Point(0, 20);
            this.tbPath.Multiline = true;
            this.tbPath.Name = "tbPath";
            this.tbPath.Size = new System.Drawing.Size(306, 37);
            this.tbPath.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(277, 239);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Cale";
            // 
            // panelPath
            // 
            this.panelPath.Controls.Add(this.lblPath);
            this.panelPath.Controls.Add(this.tbPath);
            this.panelPath.Location = new System.Drawing.Point(268, 212);
            this.panelPath.Name = "panelPath";
            this.panelPath.Size = new System.Drawing.Size(306, 60);
            this.panelPath.TabIndex = 6;
            // 
            // lblPath
            // 
            this.lblPath.AutoSize = true;
            this.lblPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPath.Location = new System.Drawing.Point(132, -3);
            this.lblPath.Name = "lblPath";
            this.lblPath.Size = new System.Drawing.Size(40, 17);
            this.lblPath.TabIndex = 5;
            this.lblPath.Text = "Cale";
            // 
            // openFile
            // 
            this.openFile.FileName = "openFileDialog1";
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 478);
            this.Controls.Add(this.panelPath);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panelResults);
            this.Controls.Add(this.panelOptions);
            this.Controls.Add(this.panelUniOrBiPort);
            this.Controls.Add(this.panelParamCache);
            this.Controls.Add(this.panelParamSim);
            this.Name = "FormMain";
            this.Text = "Simulator cache";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelParamSim.ResumeLayout(false);
            this.panelParamSim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numudLatency)).EndInit();
            this.panelParamCache.ResumeLayout(false);
            this.panelParamCache.PerformLayout();
            this.panelUniOrBiPort.ResumeLayout(false);
            this.panelUniOrBiPort.PerformLayout();
            this.panelOptions.ResumeLayout(false);
            this.panelResults.ResumeLayout(false);
            this.panelResults.PerformLayout();
            this.panelPath.ResumeLayout(false);
            this.panelPath.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelParamSim;
        private System.Windows.Forms.Panel panelParamCache;
        private System.Windows.Forms.Panel panelUniOrBiPort;
        private System.Windows.Forms.Panel panelOptions;
        private System.Windows.Forms.Panel panelResults;
        private System.Windows.Forms.Label lblSimulatorParam;
        private System.Windows.Forms.Label lblCacheParam;
        private System.Windows.Forms.ComboBox cbRegSetNumber;
        private System.Windows.Forms.Label lblRegSetNo;
        private System.Windows.Forms.ComboBox cbMissCache;
        private System.Windows.Forms.Label lblMissCache;
        private System.Windows.Forms.Label lblLatency;
        private System.Windows.Forms.Label lblIBS;
        private System.Windows.Forms.ComboBox cbIBS;
        private System.Windows.Forms.Label lblIRmax;
        private System.Windows.Forms.ComboBox cbIRmax;
        private System.Windows.Forms.Label lblFR;
        private System.Windows.Forms.ComboBox cbFR;
        private System.Windows.Forms.ComboBox cbBlockSizeData;
        private System.Windows.Forms.ComboBox cbSizeDC;
        private System.Windows.Forms.ComboBox cbSizeIC;
        private System.Windows.Forms.ComboBox cbBlockSizeInstr;
        private System.Windows.Forms.Label lblEqFR;
        private System.Windows.Forms.Label lblSizeDC;
        private System.Windows.Forms.Label lblBlockSizeData;
        private System.Windows.Forms.Label lblSizeIC;
        private System.Windows.Forms.Label lblBlockSizeInstr;
        private System.Windows.Forms.Label lblDataCache;
        private System.Windows.Forms.Label lblInstrCache;
        private System.Windows.Forms.CheckBox ckBiport;
        private System.Windows.Forms.CheckBox ckUniport;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnChooseFile;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.Label lblInstr;
        private System.Windows.Forms.TextBox tbPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelPath;
        private System.Windows.Forms.Label lblPath;
        private System.Windows.Forms.Label lblLoad;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblBranch;
        private System.Windows.Forms.Label lblStore;
        private System.Windows.Forms.Label lblTicks;
        private System.Windows.Forms.Label lblIR;
        private System.Windows.Forms.Label lblArithmetic;
        private System.Windows.Forms.TextBox tbTicks;
        private System.Windows.Forms.TextBox tbIssueRate;
        private System.Windows.Forms.TextBox tbArithmetic;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.TextBox tbBranch;
        private System.Windows.Forms.TextBox tbStore;
        private System.Windows.Forms.TextBox tbLoad;
        private System.Windows.Forms.NumericUpDown numudLatency;
        private System.Windows.Forms.OpenFileDialog openFile;
    }
}

